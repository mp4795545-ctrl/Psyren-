import * as THREE from 'three';
import './style.css';

const app = document.querySelector('#app');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x91c8df);
scene.fog = new THREE.Fog(0x91c8df, 45, 145);
const camera = new THREE.PerspectiveCamera(68, innerWidth/innerHeight, .1, 250);
const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(innerWidth,innerHeight); renderer.setPixelRatio(Math.min(devicePixelRatio,2));
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.15;
app.prepend(renderer.domElement);

scene.add(new THREE.HemisphereLight(0xd8f5ff,0x52606c,2.0));
const sun = new THREE.DirectionalLight(0xfff0d2,2.4); sun.position.set(-35,55,25); sun.castShadow=true;
sun.shadow.mapSize.set(2048,2048); sun.shadow.camera.left=-80; sun.shadow.camera.right=80; sun.shadow.camera.top=80; sun.shadow.camera.bottom=-80; scene.add(sun);

const mat=(color,roughness=.8,metalness=0)=>new THREE.MeshStandardMaterial({color,roughness,metalness});
const groundMat=mat(0x496c62), roadMat=mat(0x263541), sidewalkMat=mat(0x87969a), white=mat(0xe4edf0);
const ground=new THREE.Mesh(new THREE.PlaneGeometry(220,220),groundMat); ground.rotation.x=-Math.PI/2; ground.receiveShadow=true; scene.add(ground);
const road=new THREE.Mesh(new THREE.PlaneGeometry(18,210),roadMat); road.rotation.x=-Math.PI/2; road.position.y=.015; road.receiveShadow=true; scene.add(road);
const crossRoad=new THREE.Mesh(new THREE.PlaneGeometry(210,18),roadMat); crossRoad.rotation.x=-Math.PI/2; crossRoad.position.y=.02; scene.add(crossRoad);
for(let i=-90;i<=90;i+=10){let dash=new THREE.Mesh(new THREE.BoxGeometry(.18,.025,4),white);dash.position.set(0,.04,i);scene.add(dash);let d2=dash.clone();d2.position.set(i,.045,0);d2.rotation.y=Math.PI/2;scene.add(d2)}
// Sidewalk strips
for(const x of [-10,10]){let s=new THREE.Mesh(new THREE.BoxGeometry(2,.18,210),sidewalkMat);s.position.set(x,.08,0);s.receiveShadow=true;scene.add(s)}
for(const z of [-10,10]){let s=new THREE.Mesh(new THREE.BoxGeometry(210,.18,2),sidewalkMat);s.position.set(0,.08,z);scene.add(s)}

const buildings=[];
const colors=[0x9bb2b5,0xc7a98d,0x718c9d,0xb4c0b6,0x8c9fb4,0xd2c3a5];
for(let x=-70;x<=70;x+=14) for(let z=-70;z<=70;z+=14){
  if(Math.abs(x)<15||Math.abs(z)<15) continue;
  const w=8+Math.random()*3,d=8+Math.random()*3,h=7+Math.random()*20;
  const b=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat(colors[Math.floor(Math.random()*colors.length)]));
  b.position.set(x,h/2,z);b.castShadow=true;b.receiveShadow=true;scene.add(b);buildings.push(b);
  const roof=new THREE.Mesh(new THREE.BoxGeometry(w+.25,.35,d+.25),mat(0x526775));roof.position.set(x,h+.15,z);scene.add(roof);
  // visible windows on the sides facing the main streets
  const windowMat=new THREE.MeshStandardMaterial({color:0x9de7ed,emissive:0x28505a,roughness:.25});
  for(let yy=2;yy<h-1;yy+=3.2) for(let xx=-w/2+1;xx<w/2-1;xx+=2.2){
    for(const side of [-1,1]){const win=new THREE.Mesh(new THREE.BoxGeometry(1.05,1.15,.08),windowMat);win.position.set(x+xx,yy,z+side*(d/2+.045));scene.add(win)}
  }
}
// Trees and lamps
for(let i=0;i<65;i++){
 const x=(Math.random()-.5)*150,z=(Math.random()-.5)*150;
 if(Math.abs(x)<12||Math.abs(z)<12)continue;
 const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.22,.3,2,7),mat(0x654a35));trunk.position.set(x,1,z);trunk.castShadow=true;scene.add(trunk);
 const crown=new THREE.Mesh(new THREE.SphereGeometry(1.5,8,7),mat(0x36775b));crown.position.set(x,3,z);crown.castShadow=true;scene.add(crown);
}
for(let i=-5;i<=5;i+=2){const pole=new THREE.Mesh(new THREE.CylinderGeometry(.08,.12,4,8),mat(0x344653));pole.position.set(11,2,i*9);scene.add(pole);const bulb=new THREE.Mesh(new THREE.SphereGeometry(.22,8,8),new THREE.MeshBasicMaterial({color:0xb5f4ff}));bulb.position.set(11,4.05,i*9);scene.add(bulb)}

// Player: stylized explorer
const player=new THREE.Group();scene.add(player);
const body=new THREE.Mesh(new THREE.CapsuleGeometry(.48,.8,4,8),mat(0x244e78));body.position.y=1.05;body.castShadow=true;player.add(body);
const head=new THREE.Mesh(new THREE.SphereGeometry(.34,16,12),mat(0xe8b995));head.position.y=1.85;head.castShadow=true;player.add(head);
const visor=new THREE.Mesh(new THREE.BoxGeometry(.48,.16,.12),new THREE.MeshStandardMaterial({color:0x72eaff,emissive:0x1c7188}));visor.position.set(0,1.9,.29);player.add(visor);
const pack=new THREE.Mesh(new THREE.BoxGeometry(.55,.65,.25),mat(0x20a4a9));pack.position.set(0,1.05,-.48);player.add(pack);
player.position.set(0,0,22);

const shards=[];const shardMat=new THREE.MeshStandardMaterial({color:0x75f5ff,emissive:0x1bc9e8,emissiveIntensity:2,metalness:.4,roughness:.2});
for(let i=0;i<12;i++){
 const a=i*2.399, r=22+(i%4)*8, x=Math.cos(a)*r,z=Math.sin(a)*r;
 const g=new THREE.Group();const gem=new THREE.Mesh(new THREE.OctahedronGeometry(.65),shardMat);gem.position.y=1.3;gem.castShadow=true;g.add(gem);
 const ring=new THREE.Mesh(new THREE.TorusGeometry(.9,.035,8,32),new THREE.MeshBasicMaterial({color:0x9df7ff}));ring.rotation.x=Math.PI/2;ring.position.y=1.3;g.add(ring);
 g.position.set(x,0,z);scene.add(g);shards.push({group:g,gem,found:false});
}

let score=0,started=false,complete=false,velY=0,onGround=true,yaw=0,pitch=.18;
const keys={};let joy={x:0,y:0};let dragging=false,lastX=0,lastY=0;
const scoreEl=document.querySelector('#score'),statusEl=document.querySelector('#status');
const intro=document.querySelector('#intro'),completePanel=document.querySelector('#complete');
document.querySelector('#start').onclick=()=>{started=true;intro.classList.add('hidden')};
document.querySelector('#again').onclick=()=>location.reload();
addEventListener('keydown',e=>{keys[e.code]=true;if(e.code==='Space')jump()});
addEventListener('keyup',e=>keys[e.code]=false);
function jump(){if(started&&onGround){velY=8.5;onGround=false}}
document.querySelector('#jump').addEventListener('pointerdown',e=>{e.preventDefault();jump()});
renderer.domElement.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'){dragging=true;lastX=e.clientX;lastY=e.clientY}});
addEventListener('pointerup',()=>dragging=false);
addEventListener('pointermove',e=>{if(dragging){yaw-= (e.clientX-lastX)*.004;pitch=Math.max(-.15,Math.min(.65,pitch+(e.clientY-lastY)*.002));lastX=e.clientX;lastY=e.clientY}});
const stick=document.querySelector('#stick'),knob=document.querySelector('#knob');let stickId=null;
stick.addEventListener('pointerdown',e=>{stickId=e.pointerId;stick.setPointerCapture(stickId);moveStick(e)});
stick.addEventListener('pointermove',e=>{if(e.pointerId===stickId)moveStick(e)});
function moveStick(e){const r=stick.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;let dx=e.clientX-cx,dy=e.clientY-cy;const len=Math.hypot(dx,dy),max=34;if(len>max){dx=dx/len*max;dy=dy/len*max}joy.x=dx/max;joy.y=dy/max;knob.style.transform=`translate(${dx}px,${dy}px)`}
function resetStick(){stickId=null;joy={x:0,y:0};knob.style.transform='translate(0,0)'}
stick.addEventListener('pointerup',resetStick);stick.addEventListener('pointercancel',resetStick);

const clock=new THREE.Clock();
function animate(){
 requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04),t=clock.elapsedTime;
 shards.forEach(s=>{if(!s.found){s.group.position.y=.18+Math.sin(t*2+s.group.position.x)*.16;s.group.rotation.y+=dt*.8;s.gem.rotation.y+=dt*1.5}});
 if(started&&!complete){
  let f=(keys.KeyW||keys.ArrowUp?1:0)-(keys.KeyS||keys.ArrowDown?1:0)-joy.y;
  let str=(keys.KeyD||keys.ArrowRight?1:0)-(keys.KeyA||keys.ArrowLeft?1:0)+joy.x;
  const mag=Math.hypot(f,str);if(mag>1){f/=mag;str/=mag}
  const speed=9;const forward=new THREE.Vector3(-Math.sin(yaw),0,-Math.cos(yaw));const right=new THREE.Vector3(Math.cos(yaw),0,-Math.sin(yaw));
  player.position.addScaledVector(forward,f*speed*dt);player.position.addScaledVector(right,str*speed*dt);
  player.position.x=THREE.MathUtils.clamp(player.position.x,-98,98);player.position.z=THREE.MathUtils.clamp(player.position.z,-98,98);
  if(mag>.08)player.rotation.y=Math.atan2(-forward.x*f+right.x*str,-forward.z*f-right.z*str);
  velY-=22*dt;player.position.y+=velY*dt;if(player.position.y<=0){player.position.y=0;velY=0;onGround=true}
  for(const s of shards){if(!s.found&&player.position.distanceTo(s.group.position)<2.2){s.found=true;scene.remove(s.group);score++;scoreEl.textContent=score;statusEl.textContent='Energy shard discovered!';if(score===12){complete=true;completePanel.classList.remove('hidden')}}}
 }
 const target=new THREE.Vector3(player.position.x,player.position.y+1.5,player.position.z);
 const dist=8;const camOffset=new THREE.Vector3(Math.sin(yaw)*dist,3.2+pitch*4,Math.cos(yaw)*dist);
 camera.position.lerp(target.clone().add(camOffset),.12);camera.lookAt(target);
 renderer.render(scene,camera);
}
animate();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
