# Psyren — Open World (playable prototype)

A small 3D exploration game built with Three.js and Vite. It runs in modern desktop and mobile browsers and is structured so it can be wrapped as an Android app.

## Play on the web
1. Install Node.js (18+).
2. In this folder run `npm install`.
3. Run `npm run dev`.
4. Open the local URL shown by Vite (usually `http://localhost:5173`).

To publish: run `npm run build` and deploy the generated `dist/` folder to GitHub Pages, Netlify, or another static host.

## Controls
- Desktop: W/A/S/D or arrow keys to move; Space to jump; drag with mouse to look around.
- Touchscreen: use the on-screen joystick and JUMP button.

## Android APK (Capacitor)
1. Install Android Studio and the Android SDK.
2. Run:
   ```bash
   npm install
   npm install @capacitor/core @capacitor/cli
   npx cap init Psyren com.example.psyren --web-dir=dist
   npm run build
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
3. In Android Studio, build an APK using **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

For later updates, run `npm run build` then `npx cap sync android` before rebuilding.

## Current prototype features
- Procedurally arranged city blocks, roads, trees and street lights
- Third-person 3D explorer character and follow camera
- 12 collectible energy shards and completion screen
- Keyboard, mouse and touchscreen controls
- Responsive layout

This is a starter prototype. It does not yet include online multiplayer, accounts, cloud saves, vehicles, missions, or a backend leaderboard.
